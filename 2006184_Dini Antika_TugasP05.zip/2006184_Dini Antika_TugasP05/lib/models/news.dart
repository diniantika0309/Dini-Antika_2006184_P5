class News {
  int? id;
  String? title;
  String? description;
  String? image;

  News({this.id, this.title, this.description, this.image});
}
