import 'package:pertemuan_v/models/news.dart';

List<News> hotNews = [
  News(
    id: 6,
    title: "Dini Antika Pertemuan 5",
    description:
        "Dini adalah salah satu dan Canva Creator memiliki misi untuk membangun marketplace konten paling beragam dan terbaik di dunia. Hal ini menjadi peluang bagi para desainer, fotografer, ilustrator, seniman, dan pakar materi pelajaran untuk membagikan karya mereka dengan lebih dari 85 juta pengguna Canva. Kreator bekerja dari jarak jauh dengan fleksibilitas dan kebebasan penuh saat mereka mengajak dunia untuk mendesain.",
    image:
        "data:https://smallbiztrends.com/wp-content/uploads/2017/11/Canva.jpg",
  ),
];

List<News> newsData = [
  News(
    id: 1,
    title: "Dini Pecinta Design",
    description:
        "Ak aktif di dunia design dan creator sejak duduk dibangku kelas 3 smk",
    image:
        "https://tse1.mm.bing.net/th?id=OIP.8FpkbuuwpCq15DluF5EUHAHaFV&pid=Api&P=0",
  ),
  News(
    id: 2,
    title: "creator canva",
    description: "Sekarang menjadi canva creator",
    image: "https://i.ytimg.com/vi/DfURsbFQjKw/maxresdefault.jpg",
  ),
  News(
    id: 3,
    title: "Dunia Design",
    description: "pecinta design yang menekuni dunia creator juga",
    image:
        "https://tse2.mm.bing.net/th?id=OIP.UYsvnZxvbOMKJU0yBdhNigHaEe&pid=Api&P=0",
  ),
  News(
    id: 4,
    title: "Sukses jadi creator",
    description: "creator canva yang sukses dijuluki sebagai canva queen",
    image: "https://i.ytimg.com/vi/w11kz-DDtGw/maxresdefault.jpg",
  ),
  News(
    id: 5,
    title: "Dunia Canva",
    description: "tekuni dunai design sampai sekarang",
    image:
        "https://tse2.mm.bing.net/th?id=OIP.OAUVQ65JtkKFk26ss_VA-AHaD4&pid=Api&P=0",
  ),
];
